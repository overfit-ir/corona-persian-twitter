twitter_accounts = [
    {
        'consumer_key': 'fwSh1dSI2ZoVlgLhDJtSzNC7f',
        'consumer_key_secret': 'i6DrUhGAhxqZTiYoCQOPkApCiMyFZjyPUM7TJZESdyN35kE3VK',
        'access_token': '1082757433766875136-ZzU7Bc9szLyEDKB1Nh6VKRnVjs8Y33',
        'access_token_secret': 'fgt4FnzwRaxUxKOLTxddy8ntxMnLsv0WcI5oxalo9glxl'
    },
    {
        'consumer_key': 'kP57kuFRCocps0LrAhz9WOxCL',
        'consumer_key_secret': 'nJ28OQbbTd4fa7iLhirCa1DX516fuzliQauqqNrBYa3cWcGO4V',
        'access_token': '949062095072563201-0lfuMX9yOCzBWGrECfffYSAMgF2KWUP',
        'access_token_secret': 'NbjnFyUeHXTomZvyGRxE1nKKepWdp3skG1bAftPhJawr8'
    }
]
